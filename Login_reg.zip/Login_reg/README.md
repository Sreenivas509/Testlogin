# AngularMaterialLoginTemplate

Create login and registration UI (User Interface) template with Angular 8, Angular Flex Layout and Material design UI library.

## Step by Step Written Article
[Create Login UI Template with Angular 8 and Material Design](https://www.positronx.io/create-login-ui-template-with-angular-8-material-design/)

## How to start project?
- Git Clone Repo
- Run `npm install`
- Run `ng serve`
